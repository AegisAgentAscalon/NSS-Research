import ast,unittest,itertools
from pathlib import Path
TREE=ast.parse(Path(__file__).with_name('analyze_saved.py').read_text())
ns={};exec(compile(ast.Module(body=[x for x in TREE.body if isinstance(x,ast.FunctionDef) and x.name in ('classify','typed')],type_ignores=[]),'<selected pure functions>','exec'),ns)
class Tests(unittest.TestCase):
 def test_four_directions(self):
  self.assertEqual([ns['classify'](*x) for x in [(1,1,1),(1,0,1),(0,1,1),(0,0,1)]],['both_correct','fixes','harms','both_wrong'])
 def test_wrong_different_stays_wrong(self):self.assertEqual(ns['classify'](2,3,1),'both_wrong')
 def test_typed_dose(self):
  self.assertEqual(ns['typed']('ALL'),('str','ALL'));self.assertEqual(ns['typed'](0),('int','0'));self.assertNotEqual(ns['typed'](64),ns['typed']('64'))
 def test_all_patterns_endpoint_partition(self):
  for b in itertools.product('01',repeat=5):self.assertEqual(sum([b[0]=='1' and b[-1]=='1',b[0]=='1' and b[-1]=='0',b[0]=='0' and b[-1]=='1',b[0]=='0' and b[-1]=='0']),1)
 def test_stdlib_only(self):
  imports={x.names[0].name for x in ast.walk(TREE) if isinstance(x,ast.Import)}|{x.module for x in ast.walk(TREE) if isinstance(x,ast.ImportFrom)}
  self.assertLessEqual(imports,{'pathlib','collections','csv','json','hashlib','re','itertools','argparse'})
 def test_scoring_and_neutral_label(self):
  source=Path(__file__).with_name('analyze_saved.py').read_text()
  self.assertIn('if i>0',source);self.assertIn("p[1:]==d['target'][1:]",source);self.assertIn('wrong512_correct768_wrong1024',source);self.assertNotIn('gained_during_second_short_lost_final',source)
if __name__=='__main__':unittest.main()
