Saved-data analysis reproduction export

This is a reviewed portable export, not the original frozen program bytes.
Extract SAVED_DATA.zip into a new input directory. Extract ANALYSIS_SOURCE.zip into another directory. With Python3 standard library only, run:
python3 analyze_saved.py --inputs /your/input/directory --output /your/new/output/directory
The output directory must not already exist. Inputs must contain exactly the19 files bound by INPUT_MANIFEST.json. No NumPy, Torch, model weights, network access or scientific model code is used.
Run python3 test_analysis.py for model-free unit checks.

Export changes: replace the original workspace-relative source root and178-file recovery-receipt lookup with explicit input/output arguments and a19-file exact input manifest; update only the input-binding descriptive scope. Data grouping, matching, scoring, stage patterns, comparisons and every scientific table are unchanged. All9 CSV outputs were byte-for-byte compared with the independently verified original analysis outputs.
The original-to-export SHA256 mapping and exact selected-source identities are in EVIDENCE_MANIFEST.json. Original study/scoring status remains separate from this re-tabulation. This export reproduces the saved-data analysis only, not original model training, model evaluations or the raw-array audit.

Research plan and corrections are retained as originally written. Relative source locators inside those documents are provenance labels, not paths expected by this portable program. The source schema label confirmation denotes the prior-confirmation DEVELOPMENT panel. R128 remains descriptive.
Code license MIT; research files CC BY4.0. Owner authorized this publication scope on16October2026; licensor AegisAgentAscalon. Historical frozen plan documents retain their original permissions wording. No third-party software is distributed.
