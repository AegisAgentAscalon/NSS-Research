"""Descriptive re-tabulation of saved data. Standard library only; no model code."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,json,hashlib,re,itertools,argparse
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--inputs',required=True,type=Path)
parser.add_argument('--output',required=True,type=Path)
args=parser.parse_args()
SRC=args.inputs
OUT=args.output;OUT.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def readcsv(p):
 with p.open(newline='')as f:return list(csv.DictReader(f))
def writecsv(name,rows):
 rows=list(rows)
 with (OUT/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['empty']);w.writeheader();w.writerows(rows)
def dump(name,x):(OUT/name).write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def classify(a,b,t):
 return 'both_correct'if a==t and b==t else 'fixes'if a==t else 'harms'if b==t else 'both_wrong'
def degree(cell):
 m=re.search(r'_R(\d+)$',cell);return int(m[1])if m else None
def typed(v):
 return ('int' if type(v)is int else 'str',str(v))
bindings=[]
for p in sorted(SRC.rglob('*')):
 if p.is_file():bindings.append({'logical_path':p.relative_to(SRC).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
source_receipt=load(ROOT/'INPUT_MANIFEST.json')
expected={x['logical_path']:(x['bytes'],x['sha256'])for x in source_receipt['files']}
assert {x['logical_path']:(x['bytes'],x['sha256'])for x in bindings}==expected
dump('INPUT_BINDING.json',{'files':bindings,'analysis_plan_sha256':sha(ROOT/'ANALYSIS_PLAN.json'),'scope':'19 exact selected originals required for this saved-data analysis; original bytes unchanged.'})
memory_groups=[];memory_cases=[];primarychecks=[];swap_groups=[];error_groups=[];window_groups=[];retention_groups=[];retention_transitions=[];retention_categories=[];retention_margins=[];closure_checks=[]
for scope in ['existing','confirmation']:
 d=load(SRC/'results'/scope/'DECISION.json')['diagnostic']
 models={}
 for row in readcsv(SRC/'results'/scope/'MEMORY_PROBES.csv'):
  model=row['model']
  if not model.startswith(('CYCLIC1024_','BLOCKED1024_')):continue
  key=(row['id'],row['cell'],row['truth'],int(row['probe']))
  assert key not in models.setdefault(model,{})
  target=int(row['target']);pred=int(row['prediction']);assert (row['correct']=='True')==(target==pred)
  models[model][key]=(target,pred)
 for parent in [4101,4102]:
  a=models[f'CYCLIC1024_{parent}'];b=models[f'BLOCKED1024_{parent}'];assert a.keys()==b.keys()
  counts=defaultdict(Counter)
  for key,(t,ap)in sorted(a.items()):
   bt,bp=b[key];assert t==bt
   case,cell,truth,probe=key;direction=classify(ap,bp,t)
   memory_cases.append({'scope':scope,'parent':parent,'id':case,'cell':cell,'truth':truth,'probe':probe,'target':t,'cyclic':ap,'blocked':bp,'direction':direction,'dose':degree(cell),'descriptive_R128':degree(cell)==128})
   for dim,vals in [('total',()),('cell',(cell,)),('truth',(truth,)),('probe',(probe,)),('cell_truth',(cell,truth)),('cell_probe',(cell,probe)),('cell_truth_probe',(cell,truth,probe))]:
    c=counts[(dim,vals)];c[direction]+=1;c['targets']+=1;c['cyclic_wrong']+=ap!=t;c['blocked_wrong']+=bp!=t;c['wrong_to_different_wrong']+=ap!=t and bp!=t and ap!=bp
  for (dim,vals),c in sorted(counts.items(),key=str):
   row={'scope':scope,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'targets':c['targets'],'cyclic_wrong':c['cyclic_wrong'],'blocked_wrong':c['blocked_wrong'],'fixes':c['fixes'],'harms':c['harms'],'both_correct':c['both_correct'],'both_wrong':c['both_wrong'],'wrong_to_different_wrong':c['wrong_to_different_wrong']}
   assert c['targets']==sum(c[k]for k in ('fixes','harms','both_correct','both_wrong'))
   assert c['cyclic_wrong']-c['blocked_wrong']==c['harms']-c['fixes']
   memory_groups.append(row)
  c=counts[('cell',('NOOP_R64',))]
  orig=next(x for x in d['primary_by_parent']if x['parent']==parent);sw=next(x for x in d['primary_case_swaps']['by_parent']if x['parent']==parent)
  assert(c['cyclic_wrong'],c['blocked_wrong'],c['targets'])==(orig['CYCLIC1024'],orig['BLOCKED1024'],orig['targets'])
  assert all(c[k]==sw[k]for k in ('fixes','harms','both_correct','both_wrong','wrong_to_different_wrong'))
  primarychecks.append({'scope':scope,'parent':parent,'exact_original_primary_reconciliation':True,'source_cell':'NOOP_R64',**dict(c)})
 # All changed predictions from the matched schedule contrast; no complete-success denominator here.
 counts=defaultdict(Counter);seen=set()
 for row in readcsv(SRC/'results'/scope/'CASE_SWAPS.csv'):
  if row['contrast']!='CYCLIC1024_VS_BLOCKED1024':continue
  key=(row['parent'],row['panel'],row['id'],row['row']);assert key not in seen;seen.add(key)
  a,b,t=map(int,(row['candidate'],row['control'],row['target']))
  code=classify(a,b,t);expected_direction={'fixes':'FIX','harms':'HARM','both_wrong':'WRONG_TO_DIFFERENT_WRONG'}[code];assert row['direction']==expected_direction and a!=b
  for dim,vals in [('total',()),('panel',(row['panel'],)),('dose',(row['dose'],)),('cell',(row['cell'],)),('panel_dose',(row['panel'],row['dose'])),('base',(row['base'],)),('cell_base',(row['cell'],row['base'])),('token',(row['token'],)),('cell_token',(row['cell'],row['token']))]:
   counts[(int(row['parent']),dim,vals)][row['direction']]+=1
 for(parent,dim,vals),c in sorted(counts.items(),key=str):
  swap_groups.append({'scope':scope,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'fixes':c['FIX'],'harms':c['HARM'],'wrong_to_different_wrong':c['WRONG_TO_DIFFERENT_WRONG'],'changed_positions':sum(c.values()),'complete_denominator':False})
 # Use source error types and nonexclusive named windows without semantic recoding.
 counts=defaultdict(Counter)
 with (SRC/'results'/scope/'ERRORS.jsonl').open()as f:
  for line in f:
   row=json.loads(line);model=row['model']
   if not model.startswith(('CYCLIC1024_','BLOCKED1024_')):continue
   for dim,vals in [('total',()),('panel',(row['panel'],)),('cell',(row['cell'],)),('typed_dose',typed(row['dose'])),('base',(row['base'],)),('truth',(row['truth'],)),('window',tuple())]:
    if dim=='window':
     for window in row['windows']:counts[(model,dim,(window,))][row['error_type']]+=1
    else:counts[(model,dim,vals)][row['error_type']]+=1
 for(model,dim,vals),c in sorted(counts.items(),key=str):
  error_groups.append({'scope':scope,'model':model,'parent':int(model.rsplit('_',1)[1]),'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'FD':c['FD'],'FNC':c['FNC'],'WP':c['WP'],'errors':sum(c.values()),'windows_overlap':dim=='window'})
 score={}
 for x in readcsv(SRC/'results'/scope/'WINDOW_SCOREBOARD.csv'):
  if not x['model'].startswith(('CYCLIC1024_','BLOCKED1024_')):continue
  key=(x['model'],x['stratum'],x['window']);assert key not in score;score[key]=x
 for parent in (4101,4102):
  keys={(s,w)for model,s,w in score if model==f'CYCLIC1024_{parent}'}
  assert keys=={(s,w)for model,s,w in score if model==f'BLOCKED1024_{parent}'}
  for stratum,window in sorted(keys):
   a=score[(f'CYCLIC1024_{parent}',stratum,window)];b=score[(f'BLOCKED1024_{parent}',stratum,window)]
   assert all(a[k]==b[k]for k in ('total','paths'))
   vals={'scope':scope,'parent':parent,'stratum':stratum,'window':window,'targets':int(a['total']),'paths':int(a['paths']),'R128_descriptive':stratum.endswith('/R128'),'overlapping_windows_or_aggregate_strata_not_additive':True}
   for metric in ('wrong_answers','failed_paths','FD','FNC','WP'):
    vals['cyclic_'+metric]=int(a[metric]);vals['blocked_'+metric]=int(b[metric]);vals['delta_'+metric]=int(a[metric])-int(b[metric])
   window_groups.append(vals)
 # Retention: scored positions 1..n-1 and whole paths; no unavailable window indices are invented.
 seen=set();groups=defaultdict(Counter);trans=defaultdict(Counter);cats=defaultdict(Counter);margins=defaultdict(Counter)
 with (SRC/'results'/('diagnostic_'+scope)/'RETENTION_CASES.jsonl').open()as f:
  for line in f:
   d=json.loads(line);key=(d['order'],d['parent'],d['panel'],d['id']);assert key not in seen;seen.add(key)
   assert d['stages']==[0,256,512,768,1024] and len(d['predictions'])==5
   assert all(len(p)==len(d['target'])for p in d['predictions'])
   bits=[''.join('1'if p[i]==t else'0'for p in d['predictions'])for i,t in enumerate(d['target']) if i>0]
   pathbits=''.join('1'if p[1:]==d['target'][1:]else'0'for p in d['predictions'])
   dims=[('total',()),('panel',(d['panel'],)),('cell',(d['cell'],)),('typed_dose',typed(d['dose'])),('panel_typed_dose',(d['panel'],*typed(d['dose'])))]
   for dim,vals in dims:
    for unit,patterns in [('answer_position',bits),('whole_path',[pathbits])]:
     k=(d['order'],d['parent'],dim,vals,unit)
     groups[k].update(patterns)
     for pattern in patterns:
      cats[k]['total']+=1
      cats[k]['always_correct']+=pattern=='11111';cats[k]['always_wrong']+=pattern=='00000'
      cats[k]['baseline_preserved_final']+=pattern[0]=='1'and pattern[-1]=='1'
      cats[k]['baseline_lost_final']+=pattern[0]=='1'and pattern[-1]=='0'
      cats[k]['newly_acquired_final']+=pattern[0]=='0'and pattern[-1]=='1'
      cats[k]['baseline_wrong_final_wrong']+=pattern[0]=='0'and pattern[-1]=='0'
      cats[k]['wrong512_correct768_wrong1024']+=pattern[2:5]=='010'
      cats[k]['midpoint_correct_final_wrong']+=pattern[2]=='1'and pattern[-1]=='0'
      cats[k]['final_stage_harm']+=pattern[3:5]=='10';cats[k]['final_stage_fix']+=pattern[3:5]=='01'
      for j,stage in enumerate(d['stages']):margins[k][str(stage)]+=pattern[j]=='0'
      for j in range(4):
       trans[(*k,d['stages'][j],d['stages'][j+1])][pattern[j:j+2]]+=1
 for(order,parent,dim,vals,unit),c in sorted(groups.items(),key=str):
  for pattern in map(''.join,itertools.product('01',repeat=5)):
   retention_groups.append({'scope':scope,'order':order,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'unit':unit,'pattern':pattern,'count':c[pattern]})
 for(order,parent,dim,vals,unit),c in sorted(cats.items(),key=str):
  assert c['total']==sum(c[k]for k in ('baseline_preserved_final','baseline_lost_final','newly_acquired_final','baseline_wrong_final_wrong'))
  retention_categories.append({'scope':scope,'order':order,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'unit':unit,**c})
  retention_margins.append({'scope':scope,'order':order,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'unit':unit,'total':c['total'],**{'wrong_'+s:n for s,n in margins[(order,parent,dim,vals,unit)].items()}})
 for(order,parent,dim,vals,unit,start,end),c in sorted(trans.items(),key=str):
  retention_transitions.append({'scope':scope,'order':order,'parent':parent,'dimension':dim,'group':json.dumps(vals,separators=(',',':')),'unit':unit,'start':start,'end':end,'fixes':c['01'],'harms':c['10'],'both_correct':c['11'],'both_wrong':c['00'],'total':sum(c.values())})
 closure_checks.append({'scope':scope,'memory_pairs':sum(len(v)for k,v in models.items()if k.startswith('CYCLIC')),'matched_changed_case_positions':len(seen) if False else sum(x['changed_positions']for x in swap_groups if x['scope']==scope and x['dimension']=='total'),'retention_paths':len(seen)})
for name,rows in [('MEMORY_GROUPS.csv',memory_groups),('MEMORY_MATCHED_CASES.csv',memory_cases),('SWAP_GROUPS.csv',swap_groups),('ERROR_GROUPS.csv',error_groups),('WINDOW_GROUPS.csv',window_groups),('RETENTION_PATTERNS.csv',retention_groups),('RETENTION_TRANSITIONS.csv',retention_transitions),('RETENTION_CATEGORIES.csv',retention_categories),('RETENTION_MARGINS.csv',retention_margins)]:writecsv(name,rows)
summary={'status':'SAVED_DATA_DESCRIPTIVE_ANALYSIS_COMPLETE_PENDING_INDEPENDENT_REVIEW','primary_checks':primarychecks,'coverage':closure_checks,'original_diagnostic':load(SRC/'results/DIAGNOSTIC.json'),'scope_boundaries':['Both panels development; all new grouping hypotheses post hoc.','All matched memory probes have complete denominators. CASE_SWAPS contains changed predictions only; no both-correct denominator inferred.','Windows and RALL aggregates overlap and cannot be added. Typed ALL remains categorical, not zero.','Five-stage patterns cover only the fixed diagnostic subset and originally scored target positions 1..n-1; unscored index0 excluded and unavailable event-window indices are not reconstructed.','Evaluation delay does not define training regime; no causal attribution or parent-specific curriculum tuning.'],'model_calls':0,'training_calls':0}
dump('SUMMARY.json',summary)
assert {x['logical_path']:(x['bytes'],x['sha256'])for x in bindings}=={p.relative_to(SRC).as_posix():(p.stat().st_size,sha(p))for p in SRC.rglob('*')if p.is_file()}
dump('ANALYSIS_RECEIPT.json',{'status':'COMPLETE_INPUTS_UNCHANGED','plan_sha256':sha(ROOT/'ANALYSIS_PLAN.json'),'script_sha256':sha(Path(__file__)),'outputs':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(OUT.iterdir())],'no_model_or_scientific_imports':True})
print(json.dumps({'status':summary['status'],'coverage':closure_checks,'primary_checks':primarychecks}))
